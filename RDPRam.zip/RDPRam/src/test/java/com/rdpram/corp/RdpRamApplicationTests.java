package com.rdpram.corp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdpRamApplicationTests {

    @Test
    void contextLoads() {
    }

}
