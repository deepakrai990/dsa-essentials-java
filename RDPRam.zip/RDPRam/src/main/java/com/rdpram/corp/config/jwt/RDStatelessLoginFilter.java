package com.rdpram.corp.config.jwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.model.security.UserAuthentication;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @created 13/04/23 4:06 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
public class RDStatelessLoginFilter extends AbstractAuthenticationProcessingFilter {

    private final RDTokenAuthenticationService tokenAuthenticationService;
    private final UserDetailsService userDetailsService;

    protected RDStatelessLoginFilter(String urlMapping,
                                   RDTokenAuthenticationService tokenAuthenticationService,
                                   UserDetailsService userDetailsService,
                                   AuthenticationManager authManager) {
        super(new AntPathRequestMatcher(urlMapping));
        this.userDetailsService = userDetailsService;
        this.tokenAuthenticationService = tokenAuthenticationService;
        setAuthenticationManager(authManager);
    }

    /** Parses the {username: "xxx", password:"yyy"} json string, and attempts to login **/

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException, IOException, ServletException {

        final RDUser user = new ObjectMapper().readValue(request.getInputStream(), RDUser.class);

        final UsernamePasswordAuthenticationToken loginToken = new UsernamePasswordAuthenticationToken(
                user.getPassword(), user.getPassword());

        return getAuthenticationManager().authenticate(loginToken);
    }

    /** the login was successful. create the token **/

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                            FilterChain chain, Authentication authentication)
            throws IOException, ServletException {

        // Lookup the complete User object from the database and create an Authentication for it
        final RDCurrentUser authenticatedUser = (RDCurrentUser) userDetailsService.loadUserByUsername(authentication.getName());
        final UserAuthentication userAuthentication = new UserAuthentication(authenticatedUser);

        // Add the custom token as HTTP header to the response
        tokenAuthenticationService.addAuthentication(response, userAuthentication);

        // Add the authentication to the Security context
        SecurityContextHolder.getContext().setAuthentication(userAuthentication);
    }


}
