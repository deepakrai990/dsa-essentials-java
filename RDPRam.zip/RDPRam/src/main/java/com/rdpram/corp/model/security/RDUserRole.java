package com.rdpram.corp.model.security;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;

/**
 * @created 13/04/23 10:07 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor()
@Table(name = "rd_user_role")
public class RDUserRole {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(unique = true)
    @NonNull
    private String name;

    public RDUserRole() {

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        RDUserRole that = (RDUserRole) o;
        return getId() != null && Objects.equals(getId(), that.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
