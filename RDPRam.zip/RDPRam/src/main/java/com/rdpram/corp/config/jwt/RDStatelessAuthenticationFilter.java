package com.rdpram.corp.config.jwt;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;
import org.springframework.web.util.UrlPathHelper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @created 13/04/23 12:07 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
public class RDStatelessAuthenticationFilter extends GenericFilterBean {

    public static final String AUTHENTICATE_URL = "/api/login";

    private RDTokenAuthenticationService tokenAuthenticationService;

    public RDStatelessAuthenticationFilter(RDTokenAuthenticationService tokenAuthenticationService){
        this.tokenAuthenticationService = tokenAuthenticationService;
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) req;
        HttpServletResponse httpResponse = (HttpServletResponse) res;
        String resourcePath = new UrlPathHelper().getPathWithinApplication(httpRequest);
        try {
            if (resourcePath.contains("/api/") && AUTHENTICATE_URL.equalsIgnoreCase(resourcePath)
                    && httpRequest.getMethod().equals("POST")) {
                chain.doFilter(req, res);
            } else {
                if (resourcePath.contains("/api/")){
                    SecurityContextHolder.getContext().setAuthentication(
                            tokenAuthenticationService.getApiAuthentication((HttpServletRequest) req)
                    );
                    chain.doFilter(req, res);
                } else {
                    SecurityContextHolder.getContext().setAuthentication(
                            tokenAuthenticationService.getServerAuthentication((HttpServletRequest) req)
                    );
                    chain.doFilter(req, res);
                }
            }
        }catch(Exception authenticationException) {
            log.error(authenticationException.getMessage());
            if(resourcePath.contains("api")){
                httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, authenticationException.getMessage());
            }
        }
    }
}
