package com.rdpram.corp.repository.security;

import com.rdpram.corp.model.security.RDUser;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @created 13/04/23 11:01 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
public interface RDBaseUserRepo extends JpaRepository<RDUser,Long> {
    RDUser findByUsername(String username);

    RDUser findByEmailPrimary(String email);
}
