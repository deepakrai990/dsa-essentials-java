package com.rdpram.corp.repository.security;

import com.rdpram.corp.model.security.RDUserRole;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @created 13/04/23 11:34 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
public interface RDUserRoleRepo extends JpaRepository<RDUserRole,Long> {
    RDUserRole findByName(String name);
}
