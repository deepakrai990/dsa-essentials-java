package com.rdpram.corp.config.jwt;

import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.model.security.UserAuthentication;
import com.rdpram.corp.repository.security.RDBaseUserRepo;
import com.rdpram.corp.services.security.UserTokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.PropertyException;

/**
 * @created 13/04/23 11:43 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class RDTokenAuthenticationService {
    private static final String AUTH_HEADER_NAME = "X-AUTH-TOKEN";

    @Autowired
    UserTokenService userTokenService;

    @Autowired
    RDBaseUserRepo baseUserRepo;

    /** adds the current user's token to the header */

    public void addAuthentication(HttpServletResponse response, UserAuthentication authentication) {
        final RDCurrentUser user = authentication.getDetails();
        response.addHeader(AUTH_HEADER_NAME, userTokenService.userToToken(user));
    }

    /** retrieves the current user from the token and stores in authentication object */

    public Authentication getApiAuthentication(HttpServletRequest request) {
        log.info("Inside getAuthentication()");
        final String token = request.getHeader(AUTH_HEADER_NAME);
        log.info("getApiAuthentication() token [" + token + "]");
        if (token == null) {
            return null;
        }
        RDCurrentUser user = getUserByToken(token);
        if (user == null) {
            return null;
        }
        //RDCurrentUser baseUser = new RDCurrentUser(baseUserRepo.findByUsername(user.getUsername()));
        UserAuthentication userAuthentication = new UserAuthentication(user);
        userAuthentication.setAuthenticated(true);
        return userAuthentication;
    }

    private RDCurrentUser getUserByToken(String token) {
        RDCurrentUser user = null;
        try {
            user = userTokenService.tokenToUser(token);
        } catch (PropertyException e) {
            log.error(e.getMessage());
        }
        return user;
    }

    public Authentication getServerAuthentication(HttpServletRequest request) {
        log.info("Inside getServerAuthentication()");
        //HttpSession session = request.getSession();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        RDCurrentUser currentUser = null;
        if (auth == null) {
            return null;
        } else if(auth != null && auth.getPrincipal() == "anonymousUser") {
            return null;
        }
        log.info("use principle [" + auth.getPrincipal() + "]");
        String username = "";
        if (auth.getPrincipal() instanceof String) {
            username = (String) auth.getPrincipal();
            RDUser user = baseUserRepo.findByUsername(username);
            currentUser = new RDCurrentUser(user);
        } else {
            username = ((RDCurrentUser) auth.getPrincipal()).getUsername();
            currentUser = (RDCurrentUser) auth.getPrincipal();
        }
        if (!StringUtils.hasText(username)) {
            return null;
        }
        /*
        RDUser user = baseUserRepo.findByUsername(username);
        if(user == null) {
            return null;
        }
        */
        UserAuthentication userAuthentication = new UserAuthentication(currentUser);
        userAuthentication.setAuthenticated(true);
        return userAuthentication;
    }
}
