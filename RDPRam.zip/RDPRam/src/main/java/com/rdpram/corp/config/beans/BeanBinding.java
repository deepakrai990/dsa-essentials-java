package com.rdpram.corp.config.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * @created 13/04/23 11:31 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Component
public class BeanBinding {
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
