package com.rdpram.corp.model.security;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @created 15/04/23 4:56 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Getter
@Setter
@ToString
public class LoginForm {
    private static final long serialVersionUID = 1L;

    private String username;

    @ToString.Exclude
    private String password;
}
