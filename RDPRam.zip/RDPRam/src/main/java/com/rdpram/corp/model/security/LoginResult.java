package com.rdpram.corp.model.security;

import com.rdpram.corp.model.api.ApiResult;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @created 15/04/23 4:59 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
public class LoginResult extends ApiResult implements Serializable {
    private static final long serialVersionUID = 1L;

    public LoginResult(Boolean successful) {
        super(successful);
    }
    public LoginResult(Boolean successful, RDCurrentUser currentUser, String jwtToken) {
        super(successful);
        this.currentUser = currentUser;
        this.jwtToken = jwtToken;
    }
    private RDCurrentUser currentUser;

    @Getter
    @Setter
    private String jwtToken;
}
