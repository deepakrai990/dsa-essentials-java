package com.rdpram.corp.model.security;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;

/**
 * @created 13/04/23 10:08 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@JsonIgnoreProperties({"password"})
@Getter
@Setter
public class RDCurrentUser extends User {
    private String firstName;

    private String lastName;

    private String workPhone;

    private String emailPrimary;

    private String plainTextPassword;

    public RDCurrentUser(RDUser rdUser) {
        super(rdUser.getUsername(), rdUser.getPassword(),
                AuthorityUtils.createAuthorityList(rdUser.getRoleByUser()));
        this.buildRDCurrentUser(rdUser);
    }

    @Override
    public String toString() {
        return "RDCurrentUser{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", workPhone='" + workPhone + '\'' +
                ", emailPrimary='" + emailPrimary + '\'' +
                ", plainTextPassword='" + plainTextPassword + '\'' +
                '}';
    }

    private void buildRDCurrentUser(RDUser rdUser) {
        if (this.firstName == null) {
            this.firstName = rdUser.getFirstName();
        }
        if (this.lastName == null) {
            this.lastName = rdUser.getLastName();
        }
        if (this.workPhone == null) {
            this.workPhone = rdUser.getWorkPhone();
        }
        if (this.emailPrimary == null) {
            this.emailPrimary = rdUser.getEmailPrimary();
        }
        if (this.plainTextPassword == null) {
            this.plainTextPassword = rdUser.getPlainTextPassword();
        }
    }
}
