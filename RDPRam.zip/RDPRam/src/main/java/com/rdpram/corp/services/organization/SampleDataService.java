package com.rdpram.corp.services.organization;

import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.model.security.RDUserRole;
import com.rdpram.corp.repository.security.RDBaseUserRepo;
import com.rdpram.corp.repository.security.RDUserRoleRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

/**
 * @created 13/04/23 12:52 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class SampleDataService {
    @Autowired
    RDBaseUserRepo baseUserRepo;
    @Autowired
    RDUserRoleRepo roleRepo;
    public void createRoles() {
        if (roleRepo.findByName("ROLE_SYSTEM_SUPERUSER") == null) {
            roleRepo.save(new RDUserRole("ROLE_SYSTEM_SUPERUSER"));
        }
        if (roleRepo.findByName("ROLE_SYSTEM_SUPPORT") == null) {
            roleRepo.save(new RDUserRole("ROLE_SYSTEM_SUPPORT"));
        }
        if (roleRepo.findByName("ROLE_ADMIN") == null) {
            roleRepo.save(new RDUserRole("ROLE_ADMIN"));
        }
        if (roleRepo.findByName("ROLE_SUPERVISOR")== null) {
            roleRepo.save(new RDUserRole("ROLE_SUPERVISOR"));
        }
        if (roleRepo.findByName("ROLE_STAFF") == null) {
            roleRepo.save(new RDUserRole("ROLE_STAFF"));
        }
        if (roleRepo.findByName("ROLE_USER") == null) {
            roleRepo.save(new RDUserRole("ROLE_USER"));
        }
    }

    public void createRDUser() {
        RDUser sampleUser = baseUserRepo.findByUsername("rd_test_admin");
        log.debug("sampleUser["+ sampleUser + "] in dummy data creation");
        if (sampleUser == null) {
            sampleUser = new RDUser();
            sampleUser.setFirstName("RDAcme");
            sampleUser.setLastName("User");
            sampleUser.setWorkPhone("8189991196");
            sampleUser.setUsername("rd_test_admin");
            sampleUser.setPassword("Admin123");
            sampleUser.setEmailPrimary("kumar.deepakrai14@gmail.com");

            Set<RDUserRole> roles = new HashSet<RDUserRole>();
            roles.add(roleRepo.findByName("ROLE_ADMIN"));

            sampleUser.setRoles(roles);


            sampleUser = baseUserRepo.save(sampleUser);
            log.debug("created new sample user in Bootstrap [" + sampleUser.toString() + "]");
        }
    }
}
