package com.rdpram.corp.api;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @created 15/04/23 1:30 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@RestController
@RequestMapping("/api/admin")
@CrossOrigin("*")
public class APIAdminController {

}
