package com.rdpram.corp.config.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Locale;

/**
 * @created 15/04/23 5:13 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Component
public class Messages {

    private MessageSource messageSource;

    public Messages(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    private MessageSourceAccessor accessor;

    @PostConstruct
    private void init() {
        accessor = new MessageSourceAccessor(messageSource, Locale.ENGLISH);
    }

    public String get(String code, Object[] args) {
        if (args == null)
            return accessor.getMessage(code);
        else
            return accessor.getMessage(code, args);
    }
}
