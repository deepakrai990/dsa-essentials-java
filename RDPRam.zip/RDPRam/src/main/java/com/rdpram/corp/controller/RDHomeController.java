package com.rdpram.corp.controller;

import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.services.security.RDUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @created 13/04/23 1:35 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
@Slf4j
@Controller
public class RDHomeController {

    @Autowired
    RDUserService userService;

    @RequestMapping( value = {"/","/login"})
    public String index(Model model) {
        log.info("Inside index in login Controller");
        model.addAttribute("rdUser", new RDUser());
        RDUser rdUser = userService.getLoggedInUser();
        if (rdUser != null) {
            return "redirect:/dashboard";
        }
        return "/login/index";
    }

    @RequestMapping( value = {"/dashboard"})
    public String dashboard(Model model) {
        log.info("Inside dashboard() in login Controller");
        RDUser rdUser = userService.getLoggedInUser();
        model.addAttribute("rdUser", rdUser);
        return "/dashboard";
    }
}
