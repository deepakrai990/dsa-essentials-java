package com.rdpram.corp.model.api;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @created 15/04/23 5:00 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

public class ApiResult implements Serializable {

    public ApiResult(boolean successful) {
        this.successful = successful;
    }
    private static final long serialVersionUID = 1L;

    @Getter
    @Setter
    private boolean successful = false;
}
