package com.rdpram.corp.config.security;

import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.services.security.RDCurrentUserDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * @created 13/04/23 10:57 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Component
public class RDAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    RDCurrentUserDetailService currentUserDetailService;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        log.info("Inside authenticate");
        // get the user's credentials

        UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
        log.info("token= " +token.toString());
        String username = token.getName();
        String password = (String) token.getCredentials();

        // fetch the user taking into account the organization

        RDCurrentUser user = (RDCurrentUser) currentUserDetailService.loadUserByUsername(username);
        log.info("RDUser username[" + user.toString() + "]");
        if (user == null) {
            throw new UsernameNotFoundException("invalid username/password");
        }

        // match the password
        if (!bCryptPasswordEncoder.matches(password, user.getPassword())) {
            throw new BadCredentialsException("Invalid username/password");
        }
        log.info("Inside authenticate");
       // log.info(user.get);
        log.info("Inside authenticate");
        return new UsernamePasswordAuthenticationToken(user, password, user.getAuthorities());
    }

    /*@Override
    public boolean supports(Class<?> authentication) {
        log.info("Inside supports");
        return UsernamePasswordAuthenticationToken.class.equals(authentication);
    }*/

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

}
