package com.rdpram.corp.model.security;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @created 15/04/23 5:09 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Entity
@Table(name="rd_forget_password")
@Getter
@Setter
@NoArgsConstructor
public class ForgotPassword {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @NotNull(message = "tracking cannot be null")
    @NotBlank(message = "tracking cannot be blank")
    private String tracking;

    @NotNull(message = "url cannot be null")
    @NotBlank(message = "url cannot be blank")
    private String url;

    @OneToOne
    @JoinColumn(name="base_user_id", nullable = false)
    RDUser baseUser;

    private String browser;

    private String device;


    @JsonIgnore
    Date dateCreated;
    @JsonIgnore
    Date lastUpdated;

    @PrePersist
    protected void onCreate() {
        dateCreated = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdated = new Date();
    }
}
