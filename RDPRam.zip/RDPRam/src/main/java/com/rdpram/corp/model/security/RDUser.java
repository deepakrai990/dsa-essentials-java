package com.rdpram.corp.model.security;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.apache.tomcat.util.codec.binary.Base64;
import org.hibernate.Hibernate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Arrays;
import java.util.Date;
import java.util.Objects;
import java.util.Set;

/**
 * @created 13/04/23 10:07 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Entity
@Table(name = "rd_user")
@Getter
@Setter
@RequiredArgsConstructor
public class RDUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull(message = "Primary Email cannot be null")
    @javax.validation.constraints.NotBlank(message = "Primary Email cannot be blank")
    private String emailPrimary;

    @NotNull(message = "Username cannot be null")
    @javax.validation.constraints.NotBlank(message = "Username cannot be blank")
    private String username;

    @NotNull(message = "Password cannot be null")
    @javax.validation.constraints.NotBlank(message = "Password cannot be blank")
    @JsonIgnore
    private String password;

    @NotNull(message = "Unable to find User in System")
    @JsonIgnore
    private String plainTextPassword;

    @NotNull(message = "firstName cannot be null")
    @Size(min=1,max=30,message = "firstName must be between {min} and {max} characters long")
    @NotBlank(message = "firstName cannot be blank")
    private String firstName;

    @NotNull(message = "lastName cannot be null")
    @Size(min=1,max=30,message = "lastName must be between {min} and {max} characters long")
    @javax.validation.constraints.NotBlank(message = "lastName cannot be blank")
    private String lastName;

    @javax.validation.constraints.Email(message = "email is invalid")
    @Column(nullable = true)
    private String emailSecondary;

    @NotNull(message = "workPhone cannot be null")
    @Size(min=10,max=30,message = "workPhone must be between {min} and {max} characters long")
    @NotBlank(message = "workPhone cannot be blank")
    private String workPhone;

    @Column(nullable = true)
    @Size(min=10,max=30,message = "cellPhone must be between {min} and {max} characters long")
    private String cellPhone;

    @ManyToMany(fetch=FetchType.EAGER)
    @JoinTable
    private Set<RDUserRole> roles;

    @JsonIgnore
    Date dateCreated;
    @JsonIgnore
    Date lastUpdated;

    @NotNull(message = "LoginEnabled field cannot be null")
    private Boolean loginEnabled = true;

    @NotNull(message = "Account Locked field cannot be null")
    private Boolean accountLocked = false;

    @NotNull(message = "Credentials Expired field cannot be null")
    private Boolean credentialsExpired = false;

    @Column(nullable = true)
    private Date passwordExpiryDate = null;

    private void setPlainTextPassword(String password){
        System.out.println("Inside password " + password);
        System.out.println("password?.getBytes() = " + Arrays.toString(password.getBytes()));
        if (StringUtils.hasText(password)) {
            byte[] encoded = Base64.encodeBase64(password.getBytes());
            this.plainTextPassword = new String(encoded);
        }
    }

    public String getPlainTextPassword(){
        if (this.plainTextPassword != null) {
            byte[] decoded = Base64.decodeBase64(this.plainTextPassword);
            return new String(decoded);
        }
        return "";
    }

    @JsonIgnore
    public String[] getRoleByUser(){
        return extractNamesOfRoles();
    }

    private String[] extractNamesOfRoles() {
        String[] roleNames = new String[this.getRoles().size()];
        if (!this.getRoles().isEmpty()) {
            int sizeOfRoles = this.getRoles().size();
            for (int i = 0; i < sizeOfRoles; i++) {
                roleNames[i] = ((RDUserRole) this.getRoles().toArray()[i]).getName();
            }
            return roleNames;
        }
        return roleNames;
    }

    @PrePersist
    protected void onCreate() {
        dateCreated = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdated = new Date();
    }

    public void setPassword(String password){
        setPlainTextPassword(password);
        BCryptPasswordEncoder passEncode = new BCryptPasswordEncoder();
        this.password = passEncode.encode(password);
    }
    public String toString(){
        return this.username;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        RDUser rdUser = (RDUser) o;
        return getId() != null && Objects.equals(getId(), rdUser.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
