package com.rdpram.corp.api;

import com.rdpram.corp.model.api.ApiResponse;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.services.security.RDUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @created 15/04/23 6:49 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@RestController
@RequestMapping("/api/user")
@CrossOrigin("*")
public class APIRDUserController {

    @Autowired
    private RDUserService rdUserService;

    @GetMapping(value = "/all")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse> fetchAllUsers() {
        ApiResponse response = rdUserService.fetchAllUsers();
        if (response.isSuccessful()) {
            return new ResponseEntity<>(response, HttpStatus.FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
}
