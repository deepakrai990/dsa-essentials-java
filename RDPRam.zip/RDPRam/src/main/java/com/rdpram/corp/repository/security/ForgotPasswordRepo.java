package com.rdpram.corp.repository.security;

import com.rdpram.corp.model.security.ForgotPassword;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @created 15/04/23 5:08 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Repository
public interface ForgotPasswordRepo extends JpaRepository<ForgotPassword,Long> {
    ForgotPassword findByTracking(String tracking);

}
