package com.rdpram.corp.services.security;

import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.repository.security.RDBaseUserRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.validation.constraints.Null;
import java.util.Objects;

/**
 * @created 13/04/23 10:59 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class RDCurrentUserDetailService implements UserDetailsService {
    @Autowired
    RDBaseUserRepo baseUserRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.info("Inside loadUserByUsername");
        RDUser rdUser = baseUserRepo.findByUsername(username);
        log.info("user= " + rdUser.toString());
        if (null == rdUser) {
            throw new UsernameNotFoundException("No user found with this username[${username}]");
        } else {
            RDCurrentUser currentUser = new RDCurrentUser(rdUser);
            currentUser.setFirstName(rdUser.getFirstName());
            currentUser.setLastName(rdUser.getLastName());
            currentUser.setWorkPhone(rdUser.getWorkPhone());
            currentUser.setEmailPrimary(rdUser.getEmailPrimary());
            return currentUser;
        }
    }
}
