package com.rdpram.corp.model.api;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @created 15/04/23 6:58 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
public class ApiResponse<T> extends ApiResult implements Serializable {
    public ApiResponse(boolean successful) {
        super(successful);
    }

    public ApiResponse(boolean successful, T data) {
        super(successful);
        this.data = data;
    }
    public ApiResponse(boolean successful, T data, String message) {
        super(successful);
        this.data = data;
        this.message = message;
    }
    public ApiResponse(boolean successful, String message) {
        super(successful);
        this.message = message;
    }

    @Getter
    @Setter
    private T data;

    @Getter
    @Setter
    private String message = "";

}
