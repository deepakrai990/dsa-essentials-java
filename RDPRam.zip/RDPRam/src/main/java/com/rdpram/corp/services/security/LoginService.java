package com.rdpram.corp.services.security;

import com.rdpram.corp.config.beans.BeanBinding;
import com.rdpram.corp.config.beans.Messages;
import com.rdpram.corp.model.security.LoginForm;
import com.rdpram.corp.model.security.LoginResult;
import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.repository.security.ForgotPasswordRepo;
import com.rdpram.corp.repository.security.RDBaseUserRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @created 15/04/23 4:54 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class LoginService {

    ApplicationContext applicationContext;
    private RDCurrentUserDetailService currentUserDetailService;
    private UserTokenService userTokenService;

    private RDUserService baseUserService;
    private RDBaseUserRepo baseUserRepo;

    private ForgotPasswordRepo forgotPasswordRepo;
    private Messages messages;

    private BeanBinding binding;

    @Autowired
    public LoginService( RDCurrentUserDetailService currentUserDetailService, UserTokenService userTokenService,
                         RDUserService baseUserService, RDBaseUserRepo baseUserRepo,
                         ForgotPasswordRepo forgotPasswordRepo, Messages messages, BeanBinding binding) {
        this.currentUserDetailService = currentUserDetailService;
        this.userTokenService = userTokenService;
        this.baseUserService = baseUserService;
        this.baseUserRepo = baseUserRepo;
        this.forgotPasswordRepo = forgotPasswordRepo;
        this.messages = messages;
        this.binding = binding;
    }

    /**
     *
     * @param loginForm
     * @return
     */
    public LoginResult login(LoginForm loginForm) {

        log.info("login: "  + loginForm.toString());

        // fetch the user taking into account the organization
        RDCurrentUser user = null;
        try {
            user = (RDCurrentUser) currentUserDetailService.loadUserByUsername(loginForm.getUsername());
        } catch(Exception ex) {
            log.error("username not found: " + loginForm.getUsername());
        }
        if (null == user) {
            return new LoginResult( false);
        }
        // match the password
        BCryptPasswordEncoder bCryptPasswordEncoder = binding.bCryptPasswordEncoder();

        if (!bCryptPasswordEncoder.matches(loginForm.getPassword(), user.getPassword())) {
            log.info("incorrect password: "  + loginForm.getPassword());
            return new LoginResult(false);
        }
        log.info("login successful: " + loginForm.getUsername());

        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(user,
                user.getPassword());
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
        RDUser staff = baseUserService.getLoggedInUser();
        RDCurrentUser rdCurrentUser = new RDCurrentUser(staff);
        String jwtToken = userTokenService.userToToken(rdCurrentUser);

        log.info("jwtToken = "+ jwtToken);

        return new LoginResult(true, rdCurrentUser, jwtToken);
    }
}
