package com.rdpram.corp.api.login;

import com.rdpram.corp.model.security.LoginForm;
import com.rdpram.corp.model.security.LoginResult;
import com.rdpram.corp.services.security.LoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

/**
 * @created 15/04/23 1:33 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */
@Slf4j
@RestController
@RequestMapping("/api/login")
@CrossOrigin("*")
public class APILoginController {
    LoginService loginService;


    public APILoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping
    public ResponseEntity<LoginResult> login(@RequestBody @Valid LoginForm loginForm) {
        log.info("login(loginForm: "  + loginForm.toString() +")");
        LoginResult loginResult = loginService.login(loginForm);
        if (loginResult.isSuccessful()) {
            return new ResponseEntity<>(loginResult, HttpStatus.OK);
        }
        return new ResponseEntity<>(loginResult, HttpStatus.UNAUTHORIZED);
    }
}
