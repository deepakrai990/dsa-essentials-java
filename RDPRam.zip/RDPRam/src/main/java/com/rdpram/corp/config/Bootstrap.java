package com.rdpram.corp.config;

import com.rdpram.corp.services.organization.SampleDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @created 13/04/23 10:47 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Component
@Slf4j
public class Bootstrap implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    SampleDataService sampleDataService;
    @Autowired
    Environment env;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        sampleDataService.createRoles();
        log.debug("Profile active is ${env.getProperty()}");
        if(Objects.requireNonNull(env.getProperty("spring.profiles.active")).equalsIgnoreCase("dev")) {
            sampleDataService.createRDUser();
        }
    }
}
