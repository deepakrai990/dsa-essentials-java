package com.rdpram.corp.services.security;

import com.rdpram.corp.model.api.ApiResponse;
import com.rdpram.corp.model.api.ApiResult;
import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import com.rdpram.corp.repository.security.RDBaseUserRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @created 13/04/23 3:22 pm
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class RDUserService {

    RDBaseUserRepo userRepo;

    @Autowired
    public RDUserService(RDBaseUserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public RDUser getLoggedInUser() {
        log.info("Inside getLoggedInUser()");
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        log.debug("auth.getPrincipal() " + String.valueOf(auth.getPrincipal()));
        if(auth.getPrincipal() == "anonymousUser") {
            return null;
        }
        if(auth.getPrincipal() instanceof String){
            return userRepo.findByUsername(String.valueOf(auth.getPrincipal()));
        }
        log.info("auth ----- [" + String.valueOf(auth.getPrincipal()));
        RDCurrentUser currentUser = (RDCurrentUser) auth.getPrincipal();
        return userRepo.findByUsername(currentUser.getUsername());
    }

    public ApiResponse fetchAllUsers() {
        List<RDUser> rdUsers = userRepo.findAll();
        if (!rdUsers.isEmpty()) {
            return new ApiResponse<>(true, rdUsers);
        }
        return new ApiResponse<>(false, "Not found any users");
    }

}
