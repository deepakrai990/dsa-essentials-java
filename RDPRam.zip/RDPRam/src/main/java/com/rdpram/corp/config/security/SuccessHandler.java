package com.rdpram.corp.config.security;

import com.rdpram.corp.model.security.RDUserRole;
import com.rdpram.corp.repository.security.RDUserRoleRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @created 13/04/23 11:33 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Component
public class SuccessHandler extends SimpleUrlAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    RDUserRoleRepo roleRepo;


    public SuccessHandler() {
        super();
        setUseReferer(true);
    }

    RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                 Authentication authentication) throws IOException, ServletException {
        log.info("Inside onAuthenticationSuccess");
        handle(request, response, authentication);
        clearAuthenticationAttributes(request);
    }

    protected void handle(HttpServletRequest request,
                          HttpServletResponse response, Authentication authentication) throws IOException {
        log.info("Inside handle");
        String targetUrl = determineTargetUrl(authentication);
        if (response.isCommitted()) {
            log.debug("Response has already been committed. Unable to redirect to " + targetUrl);
            return;
        }
        /*
        String priorUrl = null;
        if (priorUrl != null && !priorUrl.contains("/login")) {
            redirectStrategy.sendRedirect(request, response, priorUrl);
        } else {
            redirectStrategy.sendRedirect(request, response, targetUrl);
        }
        */
        redirectStrategy.sendRedirect(request, response, targetUrl);
    }
    /** Builds the target URL according to the logic defined in the main class Javadoc. */
    protected String determineTargetUrl(Authentication authentication) {
        log.info("Inside determineTargetUrl");
        boolean isAdmin = false;
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        log.info("authorities= " + authorities.toString());
        for (GrantedAuthority grantedAuthority : authorities) {
            List<String> roles = roleRepo.findAll().stream()
                    .map(RDUserRole::getName)
                    .collect(Collectors.toList());;
            log.debug("Logged in user Role is " + grantedAuthority.getAuthority() +
                    " and roles of System " + Arrays.toString(roles.toArray()));
            if(roles.contains(grantedAuthority.getAuthority())){
                isAdmin = true;
                break;
            }
        }
        log.debug("Admin user " + isAdmin);
        if (isAdmin) {
            return "/dashboard";
        } else {
            throw new IllegalStateException("Illegal user trying to access resources");
        }
    }
}
