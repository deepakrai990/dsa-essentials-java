package com.rdpram.corp.config.security;

import com.rdpram.corp.config.jwt.RDStatelessAuthenticationFilter;
import com.rdpram.corp.config.jwt.RDTokenAuthenticationService;
import com.rdpram.corp.services.security.RDCurrentUserDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * @created 13/04/23 10:56 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
        securedEnabled = true,
        jsr250Enabled = true,
        prePostEnabled = true)
public class SecurityConfig {
    @Autowired
    RDCurrentUserDetailService userDetailsService;
    @Autowired
    RDAuthenticationProvider eSignAuthenticationProvider;
    @Autowired
    SuccessHandler successHandler;
    @Autowired
    RDTokenAuthenticationService tokenAuthenticationService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        log.info("Inside filterChain()");
        http
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/", "/login", "/assets/**", "/css/**", "/js/**", "/vendors/**", "/img/**").permitAll()
                .and()
                .formLogin().loginPage("/login")
                .successHandler(successHandler)
                .permitAll()
                .and()
                .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/login/?logout")
                .permitAll();
        http.addFilterBefore(new RDStatelessAuthenticationFilter(tokenAuthenticationService), BasicAuthenticationFilter.class);
        return http.build();
    }


    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        log.info("Inside authenticationManager()");
        AuthenticationManagerBuilder authenticationManagerBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .and()
                .authenticationProvider(eSignAuthenticationProvider);
        return authenticationManagerBuilder.build();
    }
}
