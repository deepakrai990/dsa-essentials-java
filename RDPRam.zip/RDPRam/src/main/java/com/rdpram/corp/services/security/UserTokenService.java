package com.rdpram.corp.services.security;

import com.rdpram.corp.model.security.RDCurrentUser;
import com.rdpram.corp.model.security.RDUser;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.xml.bind.PropertyException;

/**
 * @created 13/04/23 11:44 am
 * @project RDPRam
 * @auther Deepak Kumar Rai
 */

@Slf4j
@Service
public class UserTokenService {
    @Autowired
    RDCurrentUserDetailService currentUserDetailService;

    @Value("${token.secret}")
    String secret;

    public RDCurrentUser tokenToUser(String token) throws PropertyException {
        if (secret != null) {
            String username = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();

            return (RDCurrentUser) currentUserDetailService.loadUserByUsername(username);
        } else {
            throw new PropertyException("Not found key token.secret");
        }
    }

    public String userToToken(RDCurrentUser user) {
        if (secret != null) {
            return Jwts.builder()
                    .setSubject(user.getUsername())
                    .signWith(SignatureAlgorithm.HS512, secret)
                    .compact();
        } else  {
            throw new JwtException("token not generated");
        }
    }
}
